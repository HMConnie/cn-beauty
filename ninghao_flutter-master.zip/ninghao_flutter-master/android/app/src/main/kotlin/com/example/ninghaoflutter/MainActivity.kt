package com.example.ninghaoflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
