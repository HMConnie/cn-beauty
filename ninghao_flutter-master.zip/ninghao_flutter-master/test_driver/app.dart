import 'package:flutter_driver/driver_extension.dart';
import 'package:ninghao_flutter/main.dart' as app;

void main() {
  enableFlutterDriverExtension();

  app.main();
}